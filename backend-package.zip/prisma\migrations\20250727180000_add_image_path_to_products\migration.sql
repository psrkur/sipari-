-- AlterTable
ALTER TABLE "products" ADD COLUMN "imagePath" TEXT; 